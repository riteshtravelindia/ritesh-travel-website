
(function(){
  const $ = (s)=>document.querySelector(s);
  $('#year').textContent = new Date().getFullYear();

  const IG_HANDLE = (location.host.includes('localhost')) ? 'riteshtravelindia' : 'riteshtravelindia';
  const igLink = document.getElementById('igLink');
  igLink.href = `https://instagram.com/${IG_HANDLE}`;

  // OTP
  document.getElementById('sendOtpBtn').addEventListener('click', async ()=>{
    const phone = document.querySelector('[name="phone"]').value.trim();
    if (!phone) return alert('Enter phone first');
    const res = await fetch('/api/send-otp', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ phone }) });
    const data = await res.json();
    alert(data.message || 'OTP sent. (Demo code: 111111)');
  });

  // Lead submit + call planner
  document.getElementById('leadForm').addEventListener('submit', async (e)=>{
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    payload.pax = Number(payload.pax || 1);
    payload.days = Number(payload.days || 1);
    payload.wants_cab = !!fd.get('wants_cab');
    const otp = payload.otp;
    if (!otp) return alert('Please enter OTP (demo: 111111)');
    // Save lead
    const leadRes = await fetch('/api/lead', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const leadData = await leadRes.json();
    // Ask planner for estimates
    const travel_mode = payload.service === 'flight' ? 'flight'
                       : payload.service === 'bus' ? 'bus'
                       : 'train';
    const planRes = await fetch('/api/plan', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({
      origin: payload.origin, destination: payload.destination, pax: payload.pax, days: payload.days, wants_cab: payload.wants_cab, travel_mode
    })});
    const plan = await planRes.json();
    const box = $('#estimates');
    box.classList.remove('hide');
    box.innerHTML = (plan.options||[]).map(opt => `
      <div class="opt">
        <h4>${opt.tier}</h4>
        <p><strong>Estimated Total:</strong> ${opt.currency} ${opt.total}</p>
        <small>Includes tickets, stays, cab (if selected) & support fee. Exact price varies at booking.</small>
      </div>
    `).join('');
    window.location.hash = '#estimates';
  });
})();
